<?php

namespace App\Controllers\admin;

use App\Controllers\BaseController;
use App\Models\FAQModel;
use App\Models\DestinationModel;
use App\Models\FAQCategoryModel;

class FAQController extends BaseController
{
    protected $destinationModel;
    protected $faqModel;
    protected $faqCategoryModel;

    public function __construct()
    {
        $this->destinationModel = new DestinationModel();
        $this->faqModel = new FAQModel();
        $this->faqCategoryModel = new FAQCategoryModel();
    }

    public function index()
    {
        $data['faq'] = $this->faqModel->getAll();
        return view('pages/faq/index', $data);
    }


    public function tambah()
    {
        $data['faq_category'] = $this->faqCategoryModel->findAll();
        return view('pages/faq/tambah', $data);
    }

    public function proses_tambah()
    {
        $data = $this->request->getPost();
        $this->faqModel->insert($data);
        return redirect()->to('faq/index')->with('success', 'Data Berhasil Disimpan');
    }

    public function edit($id)
    {
        $faq = $this->faqModel->find($id);

        if ($faq !== null) {
            $data['faqData'] = $faq; // Menggunakan $faq sebagai $faqData
            $data['faq_category'] = $this->faqCategoryModel->findAll();
            return view('pages/faq/edit', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    public function proses_edit($id = null)
    {
        $data = $this->request->getPost();
        $this->faqModel->update($id, $data);
        return redirect()->to('/faq/index')->with('success', 'Data Berhasil Diupdate');
    }

public function delete($id = null)
{
    $this->faqModel->delete($id);
    return redirect()->to('/faq/index')->with('success', 'Data Berhasil Dihapus');
}


}


