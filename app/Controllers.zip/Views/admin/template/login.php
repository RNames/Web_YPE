<!DOCTYPE html>
<html lang="en">

<head>
    <title>Your Private Europe</title>

    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="robots" content="noindex">
    <meta name="description" content="Your Private Europe">
    <meta name="author" content="Xiaoying Riley at 3rd Wave Media">
    <link rel="shortcut icon" href="favicon.ico">
</head>

<body class="app app-login p-0">
    <?= $this->renderSection('content'); ?>
</body>

</html>