<?php

return [
    'form_heading' => 'ISI INFORMASI ANDA DI FORMULIR INI SELENGKAP-LENGKAPNYA',
    'name' => 'Nama',
    'phone' => 'No. Telp / Ponsel (e.g. +62-123-456-7890)',
    'email' => 'Email Address',
    'message' => 'Cantumkan: Jenis Layanan Yang Anda inginkan | Jumlah Orang | Tanggal Kedatangan & Keberangkatan | Negara-Negara Yang Ingin Dituju',
    'live' => 'Gunakan fungsi Live Chat untuk berbicara dengan salah satu anggota tim kami.',
    'send' => 'Kirim',
];
