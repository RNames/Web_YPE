<?php

return [
    'continue_reading' => 'Baca Selengkapnya',
    'by' => 'Oleh',
    'search_field' => 'Cari Disini...',
    'services' => 'Layanan Kami',
    'search_button' => 'Cari',
    'latest_article' => 'Artikel Terbaru',
    'other_article' => 'Artikel Lainnya',
    'destination_category' => 'Kategori Destinasi',
    'follow' => 'Follow Your Private Europe'
];
