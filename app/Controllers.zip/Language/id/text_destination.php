<?php

return [
    'includes' => 'Fasilitas',
    'explore_button' => 'KUNJUNGI SEKARANG',
    'text_banner' => 'Destinasi Tour Kami',
    'text_section' => 'Day & Land Tour',
    'text_title' => 'Rangkaian Day & Land Tour Yang Tersedia Untuk Private Atau Group Tour Anda'
];
