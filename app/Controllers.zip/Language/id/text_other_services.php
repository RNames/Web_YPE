<?php

return [
    'heading' => 'PELAYANAN LAINNYA',
];
