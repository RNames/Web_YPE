<?php

return [
    'heading' => 'PUSAT BANTUAN (FAQ)',
];
