<?php

return [
    'continue_reading' => 'Read More',
    'by' => 'By',
    'search_field' => 'Search Here...',
    'services' => 'Our Services',
    'search_button' => 'Search',
    'latest_article' => 'Latest Articles',
    'other_article' => 'Other Articles',
    'destination_category' => 'Destination Category',
    'follow' => 'Follow Your Private Europe'
];
