<?php

return [
    'includes' => 'Includes',
    'explore_button' => 'EXPLORE NOW',
    'text_banner' => 'Our Destination',
    'text_section' => 'Day & Land Tour',
    'text_title' => 'A Series of Day & Land Tours Available For Your Private Or Group Tours'
];
