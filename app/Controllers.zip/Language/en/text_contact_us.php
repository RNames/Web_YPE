<?php

return [
    'call_us' => 'Contact Us',
    'form_heading' => 'PLEASE FILL OUT THE FORM WITH COMPLETE INFORMATION',
    'name' => 'Name',
    'phone' => 'Phone Number / Mobile (e.g. +62-123-456-7890)',
    'email' => 'Email Address',
    'message' => 'Please Include: Type of Service You Need | Number of People | Arrival & Departure Dates | Countries You Wish to Visit',
    'live' => 'Use the Live Chat feature to speak with one of our team members.',
    'send' => 'send',
];

