<?php

return [
    'heading' => 'HELP CENTER (FAQ)',  
];
