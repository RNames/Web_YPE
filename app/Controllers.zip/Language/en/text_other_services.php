<?php

return [
    'heading' => 'OTHER SERVICES',
];
