<?php

return [
    'heading' => 'Tour Organizer & Destination Management Company in Europe',
];